import{ab as a}from"./jmuzHjgz.js";a();
